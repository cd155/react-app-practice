{-# LANGUAGE DataKinds       #-}
-- {-# LANGUAGE TemplateHaskell #-}
{-# LANGUAGE TypeOperators   #-}
{-# LANGUAGE DeriveGeneric #-}

module Lib where

import Data.Aeson
-- import Data.Aeson.TH
import Network.Wai
import Network.Wai.Handler.Warp
import Servant
import GHC.Generics
import Data.Time.Calendar
import Data.List

data User = User
  { name :: String
  , age :: Int
  , email :: String
  , registration_date :: Day
  } deriving (Eq, Show, Generic)
-- $(deriveJSON defaultOptions ''User)
instance ToJSON User

{-
  Test cases:

  Example 1: curl http://localhost:8080/users
  Example 2: curl http://localhost:8081/users2
             curl http://localhost:8081/users2/isaac
             curl http://localhost:8081/users2/albert
  Example 3: curl http://localhost:8082/position/1/2
             curl http://localhost:8082/hello
             curl http://localhost:8082/hello?name=Alp
             curl -X POST -d 
              '{"clientName": "Alp Mestanogullari", 
                "clientEmail": "alp@foo.com", 
                "clientAge": 25, 
                "clientInterestedIn": ["haskell", "mathematics"]}'
               -H 'Accept: application/json' 
               -H 'Content-type: application/json' http://localhost:8082/marketing
             curl -X POST -d '{"returnMessage": ""}'
               -H 'Accept: application/json' 
               -H 'Content-type: application/json' http://localhost:8082/message
-}

-- Example 1: simple get api
type API = "users" :> Get '[JSON] [User]

app :: Application
app = serve api server

api :: Proxy API
api = Proxy

server :: Server API
server = return users

users :: [User]
users = [ User "Isaac Newton"    372 "isaac@newton.co.uk" (fromGregorian 1683  3 1)
        , User "Albert Einstein" 136 "ae@mc2.org"         (fromGregorian 1905 12 1)
        ]

-- startApp :: IO ()
-- startApp = run 8080 app

-- Example 2: a simple api with different address
type UserAPI2 = "users" :> Get '[JSON] [User]
            :<|> "albert" :> Get '[JSON] User
            :<|> "isaac" :> Get '[JSON] User

isaac :: User
isaac = User "Isaac Newton" 372 "isaac@newton.co.uk" (fromGregorian 1683 3 1)

albert :: User
albert = User "Albert Einstein" 136 "ae@mc2.org" (fromGregorian 1905 12 1)

users2 :: [User]
users2 = [isaac, albert]

api2 :: Proxy UserAPI2
api2 = Proxy

app2 :: Application
app2 = serve api2 server2

server2 :: Server UserAPI2
server2 = return users2
      :<|> return albert
      :<|> return isaac

-- startApp2 :: IO ()
-- startApp2 = run 8081 app2

-- Example 3:
type UserAPI3 =
       "position" :> Capture "x" Int :> Capture "y" Int :> Get '[JSON] Position
  :<|> "hello" :> QueryParam "name" String :> Get '[JSON] HelloMessage
  :<|> "marketing" :> ReqBody '[JSON] ClientInfo :> Post '[JSON] Email
  :<|> "message" :> ReqBody '[JSON] Content :> Post '[JSON] Content

data Position = Position
  { xCoord :: Int
  , yCoord :: Int
  } deriving Generic

instance ToJSON Position

newtype HelloMessage = HelloMessage { msg :: String } deriving Generic

instance ToJSON HelloMessage

data ClientInfo = ClientInfo
  { clientName :: String
  , clientEmail :: String
  , clientAge :: Int
  , clientInterestedIn :: [String]
  } deriving Generic

instance FromJSON ClientInfo
instance ToJSON ClientInfo

data Email = Email
  { from :: String
  , to :: String
  , subject :: String
  , body :: String
  } deriving Generic

instance ToJSON Email

newtype Content = Content { returnMessage :: String } deriving Generic

instance FromJSON Content
instance ToJSON Content

emailForClient :: ClientInfo -> Email
emailForClient c = Email from' to' subject' body'
  where from'    = "great@company.com"
        to'      = clientEmail c
        subject' = "Hey " ++ clientName c ++ ", we miss you!"
        body'    = "Hi " ++ clientName c ++ ",\n\n"
                ++ "Since you've recently turned " ++ show (clientAge c)
                ++ ", have you checked out our latest "
                ++ intercalate ", " (clientInterestedIn c)
                ++ " products? Give us a visit!"

position :: Int -> Int -> Handler Position
position x y = return (Position x y)

hello :: Maybe String -> Handler HelloMessage
hello name = return . HelloMessage $ case name of
  Nothing -> "Hello, anonymous"
  Just n  -> "Hello, " ++ n

marketing :: ClientInfo -> Handler Email
marketing ci = return (emailForClient ci)

message :: Content -> Handler Content
message _ = return (Content "hello from the server")

server3 :: Server UserAPI3
server3 = position
     :<|> hello
     :<|> marketing
     :<|> message

api3 :: Proxy UserAPI3
api3 = Proxy

app3 :: Application
app3 = serve api3 server3

startApp3 :: IO ()
startApp3 = run 8082 app3
